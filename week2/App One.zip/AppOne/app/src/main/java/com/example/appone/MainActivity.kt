package com.example.appone

import android.os.Bundle
import android.os.PersistableBundle
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import android.view.Menu
import android.view.MenuItem
import com.example.appone.databinding.ActivityMainBinding
import android.support.v7.app.AppCompactActivity

class MainActivity : AppCompatActivity() {

    val foodlist = arrayListOf ("chinese", "hamberger" , "pizza" , "macdonalds")
    override fun onCreate(savedInstanceState: Bundle?, persistentState: PersistableBundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        decideBtn.setOnClickListener {
            val random = Random()
            val randomFood = random.nextInt(foodlist.count())
            selectedFoodTxt.text =foodList[randomFood]
        }
        addFoodBtn.setOnClickListner {
            val newFood = addFoodTxt.text.toString()
            foodlist.add(newFood)
            addFoodTxt.text.clear()
            println(foodlist)
        }
    }
}